from django.contrib import admin
from.models import *


admin.site.register([Cliente,Carro,CarroProduto,Categoria,Produto,Pedido_order])
